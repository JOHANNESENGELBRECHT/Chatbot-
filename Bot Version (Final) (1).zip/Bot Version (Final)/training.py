# importing the required modules.
import random
import json
import pickle
import numpy as np
import nltk

from keras.models import Sequential
from nltk.stem import WordNetLemmatizer
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD


lemm = WordNetLemmatizer()

# reading the json.intense file
meaning = json.loads(open("dataset.json").read())

# creating empty lists to store data
vocab = []
groups = []
docs = []
char_ignore = ["?", "!", ".", ","]
for entry in meaning['intents']:
	for ptrn in entry['patterns']:
		# separating words from patterns
		word_list = nltk.word_tokenize(ptrn)
		vocab.extend(word_list) # and adding them to words list
		
		# associating patterns with respective tags
		docs.append(((word_list), entry['tag']))

		# appending the tags to the class list
		if entry['tag'] not in groups:
			groups.append(entry['tag'])

# storing the root words or lemma
vocab = [lemm.lemmatize(word)
		for word in vocab if word not in char_ignore]
vocab = sorted(set(vocab))

# saving the words and classes list to binary files
pickle.dump(vocab, open('vocab.pkl', 'wb'))
pickle.dump(groups, open('groups.pkl', 'wb'))

# we need numerical values of the
# words because a neural network
# needs numerical values to work with
training = []
output_empty = [0]*len(groups)
for document in docs:
	bag = []
	patterns = document[0]
	patterns = [lemm.lemmatize(word.lower()) for word in patterns]
	for word in vocab:
		bag.append(1) if word in patterns else bag.append(0)
		
	# making a copy of the output_empty
	output_row = list(output_empty)
	output_row[groups.index(document[1])] = 1
	training.append([bag, output_row])
random.shuffle(training)
training = np.array(training)

# splitting the data
train_x = list(training[:, 0])
train_y = list(training[:, 1])

# creating a Sequential machine learning model
botmodel = Sequential()
botmodel.add(Dense(128, input_shape=(len(train_x[0]), ),
				activation='relu'))
botmodel.add(Dropout(0.5))
botmodel.add(Dense(64, activation='relu'))
botmodel.add(Dropout(0.5))
botmodel.add(Dense(len(train_y[0]),
				activation='softmax'))

# compiling the model
sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
botmodel.compile(loss='categorical_crossentropy',
			optimizer=sgd, metrics=['accuracy'])
hist = botmodel.fit(np.array(train_x), np.array(train_y),
				epochs=1000, batch_size=5, verbose=0)

# saving the model
botmodel.save("chatbotmodel.h5", hist)

print("Training successful.")