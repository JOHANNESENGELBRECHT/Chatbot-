import customtkinter as ctk # Import custom tkinter to make a very modern looking GUI for the chatbot
import random
import json
import pickle
import numpy as np
import nltk
from keras.models import load_model
from nltk.stem import WordNetLemmatizer

lemm = WordNetLemmatizer()

dataset = json.loads(open("dataset.json").read())
vocab = pickle.load(open('vocab.pkl', 'rb'))
groups = pickle.load(open('groups.pkl', 'rb'))
botmodel = load_model('chatbotmodel.h5')

def clean_data(sentence):
    s_words = nltk.word_tokenize(sentence)
    s_words = [lemm.lemmatize(word) for word in s_words]
    return s_words

def bagofwords(sentence):
    s_words = clean_data(sentence)
    bag = [0]*len(vocab)
    for w in s_words:
        for i, word in enumerate(vocab):
            if word == w:
                bag[i] = 1
    return np.array(bag)

def predict_group(sentence):
    bag_w = bagofwords(sentence)
    res = botmodel.predict(np.array([bag_w]))[0]
    ERROR = 0.25
    results = [[i, r] for i, r in enumerate(res) if r > ERROR]
    results.sort(key = lambda x: x[1], reverse = True)
    output_list = []
    for r in results:
        output_list.append({'intent': groups[r[0]], 'probability': str(r[1])})
    return output_list

def get_answer(list_meaning, meaning_json, confidence = 0.5):
    tag = list_meaning[0]['intent']
    intents_list = meaning_json['intents']
    output = ""
    for i in intents_list:
        if i['tag'] == tag:
            if float(list_meaning[0]['probability']) >= confidence:
                output = random.choice(i['responses'])
            else:
                output = "Sorry, I don't understand :("
            break
    return output

def add_message():
    message = entry.get()

    label = ctk.CTkLabel(scrollable_frame, text = "You: " + message, wraplength = 400)
    label.pack()

    response = get_response(message)

    label_response = ctk.CTkLabel(scrollable_frame, text = "Walley: " + response, wraplength = 400)
    label_response.pack()

    entry.delete(0, ctk.END)

def get_response(message):
    meaning = predict_group(message)
    response = get_answer(meaning, dataset, confidence = 0.5)
    return response

# Main widget (Everything else is added onto it)
root = ctk.CTk()
root.geometry("800x500")
root.title("Talk To Walley")

# Create a frame to hold the entry box
frame = ctk.CTkFrame(root)
frame.pack(fill = "x")

# Create a main title for the main form
title_label = ctk.CTkLabel(root, text = "Messages", font = ctk.CTkFont(size = 30, weight = "bold"))
title_label.pack(padx = 10, pady = (40, 20))

# Create frame for the output history
scrollable_frame = ctk.CTkScrollableFrame(root, width = 500, height = 200)
scrollable_frame.pack()

entry = ctk.CTkEntry(frame, placeholder_text = "Type Message Here")
entry.pack(fill = "x", padx = 10, pady = 10)
entry.focus_set()

add_button = ctk.CTkButton(root, text = "Send", width = 500, command = add_message)
add_button.pack(pady = 20)

# Sends message when enter key is pressed
def send_message(event = None):
    add_message()

entry.bind("<Return>", send_message)

root.mainloop() # Runs until you close it (Do not write code beneath this line)